module.exports = {
    transform: {
        "^.+\\.tsx?$": "ts-jest"
    },
    testRegex: "(/__tests__/.*| (\\.| /)(test|spec))\\.(jsx?|tsx?)$",
    moduleFileExtensions: ["ts", "tsx", "js", "jsx", "json", "node"],
    collectCoverage: true,
    collectCoverageFrom: [
        "src/**/*.ts",
        "!src/models/**",
        "!src/**/**.config.ts",
        "!src/app.ts",
        "!src/app-server.ts"
      ],
    coverageReporters: [
        "text",
        "cobertura"
      ]
};