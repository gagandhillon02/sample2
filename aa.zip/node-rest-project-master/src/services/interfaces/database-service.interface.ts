import { ExecuteOptions, Result } from 'oracledb';

export interface IDatabaseService {
    initialize(): void;

    close(): void;

    simpleExecute(statement: string, binds: any): Promise<Result>;

    getBindParameters(statement: string): string[];

    parameterMapper(bindKeys: string[], object: object): object;
}
