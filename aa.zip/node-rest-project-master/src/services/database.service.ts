import oracledb, { ExecuteOptions, Result } from 'oracledb';
import { dbConfig } from '../utils/database.config';
import { logger } from '../utils/winston.config';
import { injectable } from 'inversify';
import { loggable } from '../utils/logger.util';

@injectable()
export class DatabaseService {

    @loggable()
    public async initialize() {
        await oracledb.createPool(dbConfig);
    }


    public async close() {
        await oracledb.getPool().close();
    }

    @loggable()
    public simpleExecute(statement: string, binds: any = [], opts: ExecuteOptions = {}): Promise<Result> {
        return new Promise(async (resolve, reject) => {
            let conn;

            opts.outFormat = oracledb.OUT_FORMAT_OBJECT;
            opts.autoCommit = true;

            if (!(binds instanceof Array) && typeof binds === 'object') {
                let bindParams = this.getBindParameters(statement);
                binds = this.parameterMapper(bindParams, binds);
            }

            try {
                conn = await oracledb.getConnection();

                const result = await conn.execute(statement, binds, opts);

                resolve(result);
            } catch (err) {
                reject(err);
            } finally {
                if (conn) { // conn assignment worked, need to close
                    try {
                        await conn.close();
                    } catch (err) {
                        logger.error(err);
                    }
                }
            }
        });
    }

    @loggable()
    public getBindParameters(statement: string): string[] {

        const array = statement.match(/(:\w+)/g);
        if (array) {
            const result = array.map((element) => element.replace(':', ''));
            return result;
        }
        return [];
    }

    @loggable()
    public parameterMapper(bindKeys: string[], object: object): object {

        const keys: string[] = Object.keys(object);

        keys.forEach((e) => {
            if (!bindKeys.includes(e)) {
                delete (object as any)[e];
            }
        });

        return object;
    }
}