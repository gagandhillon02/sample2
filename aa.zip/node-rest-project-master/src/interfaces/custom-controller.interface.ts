import { Appeal } from "../models/appeal.model";
import { Request, Response, NextFunction } from 'express';

export interface CustomController {

    handleSuccess(value: Appeal[], res: Response): void;

    handleError(error: any, next: NextFunction): void;

    validateReceivedData(req: Request): void;
}