const Symbols = {
    // IAppealsController: Symbol.for('IAppealsController'),
    // IAppealsRepository: Symbol.for('IAppealsRepository'),
    // IApplicationsController: Symbol.for('IApplicationsController'),
    // IApplicationsRepository: Symbol.for('IApplicationsRepository'),
    // IPlanSponsorsController: Symbol.for('IPlanSponsorsController'),
    // IPlanSponsorsRepository: Symbol.for('IPlanSponsorsRepository'),
    IDatabaseService: Symbol.for('IDatabaseService'),
};

export { Symbols };
