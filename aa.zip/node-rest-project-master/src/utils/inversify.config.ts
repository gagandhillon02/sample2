import { Container } from 'inversify';
import { DatabaseService } from '../services/database.service';
import { IDatabaseService } from '../services/interfaces/database-service.interface';

let container = new Container(); // Initialize the IOC bindings
// container.bind<IAppealsController>(Symbols.IAppealsController).to(ApplealsController);
// container.bind<AppealsRouter>(AppealsRouter).toSelf();

export default container;
