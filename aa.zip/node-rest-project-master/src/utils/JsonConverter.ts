import { JsonConvert, OperationMode, ValueCheckingMode } from 'json2typescript';

 let jsonMapper: JsonConvert = new JsonConvert();
 jsonMapper.operationMode = OperationMode.ENABLE; // print some debug data
 jsonMapper.ignorePrimitiveChecks = false; // don't allow assigning number to string etc.
 jsonMapper.valueCheckingMode = ValueCheckingMode.ALLOW_NULL;

 export {jsonMapper};
 