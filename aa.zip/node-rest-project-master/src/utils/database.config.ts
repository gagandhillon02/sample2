import CryptoJS from 'crypto-js';
import { PoolAttributes } from 'oracledb';
import data from '../config/config.json'; // This should be the path of a docker volume folder
import { logger } from './winston.config';

const profile: string = process.env.DEPLOY_ENV || 'dev'; // get profile from env variable

logger.info('Profile active: ' + profile);
const dbKey: string = process.env.DB_CRYPT || ''; // get decryption key from environment

const confiData = data.db as { [key: string]: any };

const dbPassword = CryptoJS.AES.decrypt(confiData[profile].password, dbKey).toString(CryptoJS.enc.Utf8); // decrypt db password

// const dbPassword = confiData[profile].password;

let dbConfig: PoolAttributes;

if (dbKey) {
    dbConfig = {
        user: process.env.NODE_ORACLEDB_USER || confiData[profile].user,
        password: process.env.NODE_ORACLEDB_PASSWORD || dbPassword,
        connectString: process.env.NODE_ORACLEDB_CONNECTIONSTRING || confiData[profile].connectString,
        poolMin: confiData[profile].poolMin,
        poolMax: confiData[profile].poolMax,
        poolIncrement: confiData[profile].poolIncrement,
    };
}

export { dbConfig, profile };
