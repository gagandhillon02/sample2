import path from 'path';

let rootDir: string = process.mainModule ? path.dirname(process.mainModule!.filename) : '';
let serverPort: number = 8080; // Set your desired port
let contextPath: string = '/new-service';
let version: string = '0.0.1';

export { rootDir, serverPort, contextPath, version };
