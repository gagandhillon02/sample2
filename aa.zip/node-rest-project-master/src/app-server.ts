import express from 'express';
import { Server } from 'http';
import 'reflect-metadata';
// import { AppealsRouter } from './routes/appeals.router';
import { DatabaseService } from './services/database.service';
import { contextPath, serverPort, version } from './utils/app.config';
import container from './utils/inversify.config';
import { ewLogger, logger } from './utils/winston.config';
import httpContext from 'express-http-context';

export class AppServer {
    public static readonly PORT: number = serverPort;
    private app!: express.Application;
    private port!: string | number;
    private database!: DatabaseService;
    // private appealsRouter!: AppealsRouter;
    public server!: Server;

    constructor() {
        this.startup();
    }

    private startup() {
        logger.info('Starting application');
        this.initIoC();
        this.initDatabase();
        this.createApp();
        this.config();
        this.listen();
    }

    private createApp(): void {
        logger.info('Creating Server');
        this.app = express();
    }

    private config(): void {
        logger.info('Configuring Server');

        this.port = process.env.PORT || AppServer.PORT;

        // support application/json type post data
        this.app.use(express.json());

        this.app.use(httpContext.middleware);

        // Run the context for each request. Read the unique idetifier sent by upstream service
        this.app.use((req, res, next) => {
            httpContext.set('traceId', req.headers['x-b3-traceid']);
            next();
        });

       // // Combines logging info from request and response
       this.app.use(ewLogger);

        this.app.use((req, res, next) => {
            res.setHeader('Access-Control-Allow-Origin', '*');
            res.setHeader(
                'Access-Control-Allow-Methods',
                'OPTIONS, GET, POST, PUT, PATCH, DELETE'
            );
            res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
            next();
        });

        this.app.get(contextPath + '/version', (req, res) => res.send(version));

        this.app.use(contextPath + this.appealsRouter.path, this.appealsRouter.router);
    }

    private listen(): void {
        this.server = this.app.listen(this.port, () => {
            logger.info('Running server on port %s', this.port);
        });
    }

    private async initDatabase(): Promise<void> {
        try {
            logger.info('Initializing database module');
            await this.database.initialize();
        } catch (err) {
            logger.error(err);

            process.exit(1); // Non-zero failure code
        }
    }

    public getApp(): express.Application {
        return this.app;
    }

    private initIoC(): void {
        logger.info('Resolving IoC Dependency Container');
        this.database = container.resolve<DatabaseService>(DatabaseService);
        // this.appealsRouter = container.resolve<AppealsRouter>(AppealsRouter);
    }

    async shutdown(e?: Error) {
        let err = e;
    
        logger.info('Shutting down application');
    
        try {
            logger.info('Closing web server module');
    
            await this.server.close();
        } catch (e) {
            logger.error(e);
    
            err = err || e;
        }
    
        try {
            logger.info('Closing database module');
    
            await this.database.close();
        } catch (e) {
            logger.error(e);
    
            err = err || e;
        }
    
        logger.info('Exiting process');
    
        if (err) {
            process.exit(1); // Non-zero failure code
        } else {
            process.exit(0);
        }
    }
}
