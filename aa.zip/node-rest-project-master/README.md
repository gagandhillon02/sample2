# node-rest-project
This is NodeJS typescript Base project for REST services.

How to use
----------
Clone the project to your local computer:

`git clone https://ip-10-245-233-182.ec2.internal/rdsdev/node-rest-project.git` 

Important Set a new remote origin:

`git remote add origin https://ip-10-245-233-182.ec2.internal/rdsdev/your_new_repo.git`

Run `npm install` inside this project folder to install all dependencies.

Run `npm start` to start the application in development mode.

This project contains the base folder structure and abstract classes needed for you to start developing a new RestFul web service.

## TODO

A Pending task is to install and configure a new IOC dependency injection framework to reduce boiler plate code.

## Configuration files

`AppConfig.ts` Here you can change the default server port (8080) to any desired value.

`DatabaseConfig.ts` Here you can change the credentials configuration to connect to the OracleDB.

`WinstonConfig.ts` This project uses Winston as logger framework to generate app logs. Here you can configure the format, size and rotation of logs generated.

## Build

Run `npm run build` to build the project for production. The build artifacts will be stored in the `dist/` directory.

TODO reduce dependencies folder size.

## Deployment

Run `docker build --squash -t [name]:[tag]` to generate the final container. 

(Note) you will require the base image. For that you can build one using the `Dockerfile-Base` file.

The `squash` flag in the previous command is an experimental feature of docker. It reduces the size of the final image. Make sure to enable experimental features in the docker daemon.
